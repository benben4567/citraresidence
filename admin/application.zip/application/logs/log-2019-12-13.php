<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-13 09:11:09 --> Severity: Notice --> Undefined index: log_threshold D:\Scripts\codecanyon-19743446-hotel-management-system\hms\system\core\Log.php 129
ERROR - 2019-12-13 09:11:09 --> Severity: Notice --> Undefined index: log_threshold D:\Scripts\codecanyon-19743446-hotel-management-system\hms\system\core\Log.php 133
ERROR - 2019-12-13 09:11:09 --> Query error: Table 'sc_hotel.room_types' doesn't exist - Invalid query: SELECT *
FROM `room_types`
ERROR - 2019-12-13 09:11:09 --> Severity: error --> Exception: Class 'CI_Controller' not found D:\Scripts\codecanyon-19743446-hotel-management-system\hms\system\core\CodeIgniter.php 366
ERROR - 2019-12-13 09:11:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Scripts\codecanyon-19743446-hotel-management-system\hms\system\core\Log.php:129) D:\Scripts\codecanyon-19743446-hotel-management-system\hms\system\core\Common.php 573
